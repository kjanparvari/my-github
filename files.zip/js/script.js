(() => {
    const submitButton = document.getElementById("submitButton");
    const usernameTextBox = document.getElementById("username");
    const avatar = document.getElementById("avatar");
    const nameLabel = document.getElementById("name");
    const blogLabel = document.getElementById("blog");
    const locationLabel = document.getElementById("location");
    const bio = document.getElementById("bio");
    const infoContainer = document.getElementById("infoContainer");
    const errorContainer = document.getElementById("errorContainer");
    const errorPara = document.getElementById("errorMsg");

    window.onload = () => {
        submitButton.addEventListener('click', async () => {
            const username = usernameTextBox.value;
            await getInfo(username);
        });
    }


    const getInfo = async (username) => {
        const url = `https://api.github.com/users/${username}`;
        console.log(`url: ${url}`);
        try {
            const cached = window.localStorage.getItem(username);
            if (cached === null) {
                await fetch(url).then(async (response) => {
                    console.log(response.status)
                    if (response.status >= 400) {
                        const data = await response.json();
                        showError(data["message"]);
                    } else if (response.status === 200) {
                        const data = await response.json();
                        localStorage.setItem(username, JSON.stringify(data));
                        showInfo(data);
                    }
                });
            } else {
                showInfo(JSON.parse(cached))
            }

        } catch (e) {
            showError('An Connection Error Happened')
        }
    }

    const showInfo = (data) => {
        infoContainer.classList.remove("disabled");
        if (!errorContainer.classList.contains("disabled"))
            errorContainer.classList.add("disabled");
        nameLabel.innerHTML = data["name"];
        blogLabel.innerHTML = data["blog"];
        blogLabel.href = data["blog"];
        locationLabel.innerHTML = data["location"];
        avatar.src = data["avatar_url"];
        bio.innerHTML = "";
        if (data["bio"] !== null){
            data["bio"].split("\r\n").map((line) => {
                const para = document.createElement("p");
                para.appendChild(document.createTextNode(line));
                para.className = "bio__line";
                bio.appendChild(para)
            });
        }

    }

    const showError = (msg) => {
        errorContainer.classList.remove("disabled");
        if (!infoContainer.classList.contains("disabled"))
            infoContainer.classList.add("disabled");
        errorPara.innerHTML = msg;
    }
})()